package com.web.dao;

import com.web.model.Mensaje;
import com.web.model.Trabajador;

public interface TrabajadorDAO {

	Mensaje agregarTrabajador(Trabajador trabajador);
}
