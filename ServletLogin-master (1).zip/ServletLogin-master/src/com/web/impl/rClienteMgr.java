package com.web.impl;

import com.web.model.Empresa;

public interface rClienteMgr {

	String validarUserCliente(Empresa userCliente ); 
		
	
}
