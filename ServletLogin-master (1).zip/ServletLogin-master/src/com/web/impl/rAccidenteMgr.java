package com.web.impl;

import com.web.model.RAccidentes;

public interface rAccidenteMgr {

	String validarUsuarioAccidente(RAccidentes newAccidente ); 
	
}
