package com.web.impl;

import com.web.model.Mensaje;
import com.web.model.Trabajador;

public interface TrabajadoresMgr {

	Mensaje agregarTrabajador(Trabajador trabajador);

}
